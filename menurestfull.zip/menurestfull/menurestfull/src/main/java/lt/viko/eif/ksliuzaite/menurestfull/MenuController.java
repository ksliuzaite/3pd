package lt.viko.eif.ksliuzaite.menurestfull;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class MenuController {

    private MenuService menuService;

    public MenuController(MenuService menuService) {
        super();
        this.menuService = menuService;
    }

    // handler method to handle list dishes and return mode and view
    @GetMapping("/dishes")
    public String listDish(Model model) {
        model.addAttribute("dishes", menuService.getAllDishes());
        return "dishes";
    }

    @GetMapping("/dishes/new")
    public String createDishForm(Model model) {

        // create dish object to hold dish form data
        Dish dish = new Dish();
        model.addAttribute("dish", dish);
        return "create_dish";

    }

    @PostMapping("/dishes")
    public String saveDish(@ModelAttribute("dish") Dish dish) {
        menuService.saveDish(dish);
        return "redirect:/dishes";
    }

    @GetMapping("/dishes/edit/{id}")
    public String editDishForm(@PathVariable Long id, Model model) {
        model.addAttribute("dish", menuService.getDishById(id));
        return "edit_dish";
    }

    @PostMapping("/dishes/{id}")
    public String updateDish(@PathVariable Long id,
                                @ModelAttribute("dish") Dish dish,
                                Model model) {

        // get dish from database by id
        Dish existingDish = menuService.getDishById(id);
        existingDish.setId(id);
        existingDish.setName_of_dish(dish.getName_of_dish());
        existingDish.setPrice(dish.getPrice());
        existingDish.setName_of_ingredient(dish.getName_of_ingredient());
        existingDish.setName_of_allergen(dish.getName_of_allergen());

        // save updated dishes object
        menuService.updateDish(existingDish);
        return "redirect:/dishes";
    }

    // handler method to handle delete dish request

    @GetMapping("/dishes/{id}")
    public String deleteDish(@PathVariable Long id) {
        menuService.deleteDishById(id);
        return "redirect:/dishes";
    }

}
