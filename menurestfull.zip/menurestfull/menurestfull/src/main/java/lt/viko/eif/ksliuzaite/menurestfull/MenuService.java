package lt.viko.eif.ksliuzaite.menurestfull;

import java.util.List;
import lt.viko.eif.ksliuzaite.menurestfull.Dish;

public interface MenuService {

    List<Dish> getAllDishes();

    Dish saveDish(Dish dish);

    Dish getDishById(Long id);

    Dish updateDish(Dish dish);

    void deleteDishById(Long id);

}
