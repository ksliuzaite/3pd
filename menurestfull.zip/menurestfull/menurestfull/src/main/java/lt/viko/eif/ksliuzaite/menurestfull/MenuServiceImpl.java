package lt.viko.eif.ksliuzaite.menurestfull;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MenuServiceImpl implements MenuService {

    private MenuRepository menuRepository;

    public MenuServiceImpl(MenuRepository menuRepository) {
        super();
        this.menuRepository = menuRepository;
    }

    @Override
    public List<Dish> getAllDishes() {
        return menuRepository.findAll();
    }

    @Override
    public Dish saveDish(Dish dish) {
        return menuRepository.save(dish);
    }

    @Override
    public Dish getDishById(Long id) {
        return menuRepository.findById(id).get();
    }

    @Override
    public Dish updateDish(Dish dish) {
        return menuRepository.save(dish);
    }

    @Override
    public void deleteDishById(Long id) {
        menuRepository.deleteById(id);
    }

}
