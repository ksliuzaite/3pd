package lt.viko.eif.ksliuzaite.menurestfull;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MenurestfullApplication {

	public static void main(String[] args) {
		SpringApplication.run(MenurestfullApplication.class, args);
	}

}
