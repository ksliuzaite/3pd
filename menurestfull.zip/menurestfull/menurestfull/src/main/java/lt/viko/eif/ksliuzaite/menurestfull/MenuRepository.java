package lt.viko.eif.ksliuzaite.menurestfull;

import org.springframework.data.jpa.repository.JpaRepository;

import lt.viko.eif.ksliuzaite.menurestfull.Dish;

public interface MenuRepository extends JpaRepository<Dish, Long>{
}
