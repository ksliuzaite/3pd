package lt.viko.eif.ksliuzaite.menurestfull;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "dishes")
public class Dish {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "name_of_dish", nullable = false)
    private String name_of_dish;

    @Column(name = "ingredient")
    private String name_of_ingredient;

    @Column(name = "allergens")
    private String name_of_allergen;

    @Column(name = "price")
    private int price;

    public Dish() {

    }

    public Dish (String name_of_dish, String ingredient, String allergen, int price) {
        super();
        this.name_of_dish = name_of_dish;
        this.price = price;
        this.name_of_ingredient = ingredient;
        this.name_of_allergen = allergen;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName_of_dish() {
        return name_of_dish;
    }

    public void setName_of_dish(String name_of_dish) {
        this.name_of_dish = name_of_dish;
    }

    public String getName_of_ingredient() {
        return name_of_ingredient;
    }

    public void setName_of_ingredient(String name_of_ingredient) {
        this.name_of_ingredient = name_of_ingredient;
    }

    public String getName_of_allergen() {
        return name_of_allergen;
    }

    public void setName_of_allergen(String name_of_allergen) {
        this.name_of_allergen = name_of_allergen;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
}
